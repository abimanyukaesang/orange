$(document).ready(function () {

  // burger menu close
  $(".navbar-nav li a").click(function (event) {
    $(".navbar-collapse").collapse('hide');
  });
  

  //Create classOnScroll function
  function classOnScroll() {
    let $box = $('.navbar'),
      $scroll = $(window).scrollTop();

    if ($scroll > 100) {
      if (!$box.hasClass('solid in-down'))
        $box.addClass('solid in-down');
    }
    else
      $box.removeClass('solid in-down');

  }



  //Run on first site run
  classOnScroll();

  //Run on scroll and resize
  $(window).on('scroll resize', classOnScroll);
});