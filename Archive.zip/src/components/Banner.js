import React from 'react';
import '../assets/scss/Banner.scss';

const Banner =(props) =>(
    <div className='banner'>
         { props.bannerName }
    </div>
)

export default Banner;