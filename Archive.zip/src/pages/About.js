import React from 'react';

const About =() =>(
    <div>
        <div className='container'>
            <div className='row'>
                <div className='col-md-12'>
                    ini adalah halaman about
                </div>
            </div>
        </div>
    </div>
)

export default About;