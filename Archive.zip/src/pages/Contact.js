import React from 'react';
import '../assets/scss/Contact.scss'
import Banner from '../components/Banner';

import Slide1 from '../assets/images/bg-contact.jpg';

const slide1 = {backgroundImage: 'url(' + Slide1 + ')',};

const Contact =() => (
    <div>
        <Banner bannerName={"tes"}/>
    </div>
)

export default Contact;