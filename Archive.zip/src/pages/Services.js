import React from 'react';

const Service =() => (
    <div>
        <div className='container'>
            <div className='row'>
                <div className='col-md-12'>
                    ini halaman service
                </div>
            </div>
        </div>
    </div>
)

export default Service;