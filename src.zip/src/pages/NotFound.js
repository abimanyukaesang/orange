import React from "react";

function NotFound() {
  return <>Page not found</>;
}

export default NotFound;
